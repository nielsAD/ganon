<?php

include_once('../ganon.php');

$input = '<div><span>Foo</span><span class="test">Bar</span></div>';
$html = str_get_dom($input);

$span = $html('.test', 0);
$span->setTag('h3', true);

echo $html;

?>
<?php
/**
 * Should output all Wiki articles and their information from the Ganon page
 * at Google Code (http://code.google.com/p/ganon/w/list)
 *
 * Demonstrates (advanced) selectors and nested queries
 *
 * @author Niels A.D.
 * @package Ganon
 * @link http://code.google.com/p/ganon/
 * @license http://dev.perl.org/licenses/artistic.html Artistic License
 */

include_once('../ganon.php');
//PHP4 users, make sure this path is correct!

$html = file_get_dom('http://www.google.it/language_tools');

echo $html('#gt-appname', 0)->getInnerText();


?>